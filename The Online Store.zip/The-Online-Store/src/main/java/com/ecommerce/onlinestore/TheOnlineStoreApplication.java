package com.ecommerce.onlinestore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TheOnlineStoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(TheOnlineStoreApplication.class, args);
	}

}
