package com.ecommerce.onlinestore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TheOnlineStoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
